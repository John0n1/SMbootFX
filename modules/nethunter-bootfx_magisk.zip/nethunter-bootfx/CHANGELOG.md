# Kali Boot Animation Changelog

## v1.5.2 (Initial Release)
- Initial release of Nethunter boot animation
- Custom bootsamsung.qmg, bootsamsungloop.qmg, and shutdown.qmg
- Automatic backup and restore functionality
- Device compatibility checking
- Samsung device optimization
- Auto-update support via GitHub