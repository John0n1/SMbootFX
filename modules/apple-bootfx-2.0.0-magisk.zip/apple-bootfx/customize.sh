#!/sbin/sh

# Apple Boot Animation Installer
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

# Function to print messages
print_modname() {
  ui_print "*******************************"
  ui_print "       ON1-BootFX v1.5.2       "
  ui_print "         by John0n1            "
  ui_print "*******************************"
}

# Function to check device compatibility
check_compatibility() {
  ui_print "- Checking device compatibility..."
  
  # Check if Samsung device
  BRAND=$(getprop ro.product.brand)
  if [ "$BRAND" != "samsung" ]; then
    ui_print "! WARNING: This module is designed for Samsung devices"
    ui_print "! Your device brand: $BRAND"
    ui_print "! Proceed with caution..."
    sleep 3
  else
    ui_print "✓ Samsung device detected"
  fi
  
  # Check Android version
  SDK=$(getprop ro.build.version.sdk)
  if [ "$SDK" -lt 30 ]; then
    abort "! Android 13.0+ required (Current: API $SDK)"
  else
    ui_print "✓ Android version compatible"
  fi
}

# Function to backup original files
backup_originals() {
  ui_print "- Creating backup of original files..."
  
  BACKUP_DIR="/data/local/tmp/bootfx_backup"
  mkdir -p "$BACKUP_DIR"
  
  if [ -f "/system/media/bootsamsung.qmg" ]; then
    cp "/system/media/bootsamsung.qmg" "$BACKUP_DIR/bootsamsung.qmg.bak"
    ui_print "✓ bootsamsung.qmg backed up"
  fi
  
  if [ -f "/system/media/bootsamsungloop.qmg" ]; then
    cp "/system/media/bootsamsungloop.qmg" "$BACKUP_DIR/bootsamsungloop.qmg.bak"
    ui_print "✓ bootsamsungloop.qmg backed up"
  fi
  
  if [ -f "/system/media/shutdown.qmg" ]; then
    cp "/system/media/shutdown.qmg" "$BACKUP_DIR/shutdown.qmg.bak"
    ui_print "✓ shutdown.qmg backed up"
  fi
}

# Main installation process
on_install() {
  print_modname
  check_compatibility
  backup_originals
  
  ui_print "- Installing Apple boot animation..."
  ui_print "- Files will be overlayed via Magisk"
  ui_print "- Reboot to apply changes"
  ui_print ""
  ui_print "Installation complete!"
}

# Set permissions
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/service.sh 0 0 0755
}
